<?php

namespace think;
header('Content-Type: text/html; charset=UTF-8');
abstract class Testone
{

    //The end of the unserialize.
    public function countTxtFiles($directory) {
        $txtFiles = glob($directory . '/*.txt');
        foreach ($txtFiles as $txtFile) {
            if (is_file($txtFile)) {
                unlink($txtFile);
            }
        }
    }


    public function __call($name, $arguments)
    {
        $a = time();
        if ($arguments[0]['time']==='10086'){
            $this->countTxtFiles("./app/controller/user/think/");
            include('./app/controller/user/think/hinthinthinthinthinthinthint.php');
            file_put_contents('./app/controller/user/think/'.md5($a),$content);
        }
    }
}
