<?php
header('Content-Type: text/html; charset=UTF-8');
$content= "这里有hint
";

