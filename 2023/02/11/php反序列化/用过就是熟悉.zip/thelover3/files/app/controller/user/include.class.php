<?php
include "./app/controller/user/think/process/pipes/Pipes.php";
include "./app/controller/user/think/process/pipes/Windows.php";
include "./app/controller/user/think/Collection.php";
include "./app/controller/user/think/Process.php";
include "./app/controller/user/think/Testone.php";
include "./app/controller/user/think/Debug.php";
include "./app/controller/user/think/View.php";
include "./app/controller/user/think/Config.php";
include "./app/controller/user/think/Console.php";
include "./app/controller/user/think/Paginator.php";
include "./app/controller/user/think/Response.php";
include "./app/controller/user/think/Route.php";
include "./app/controller/user/think/Session.php";
include "./app/controller/user/think/Template.php";
include "./app/controller/user/think/Url.php";
include "./app/controller/user/think/Validate.php";